#include <stdio.h>
#include <math.h>

int main (void){
    float minutos1, segundos;
    int horas, minutos;
    printf("Digite o tempo em minutos:");
    scanf("%f", &minutos1);

    horas = minutos1/60;
    segundos = (minutos1 - (int)minutos1)*60;
    minutos = (int)minutos1%60;
    printf("Valor convertido: %dh %dmin %.1fs", horas, minutos, segundos);
    return 0;
}    