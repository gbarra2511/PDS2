#include <stdio.h>
#include <math.h>

int main (void){
int segundos;{
    printf("Digite o tempo em segundos:\n");
    scanf("%d", &segundos);
}
int min, hrs, s;
hrs = segundos/pow(60,2);
min = (segundos%3600)/60;
s = (segundos%3600)%60;
{
    printf("%dh %dmin %ds\n", hrs, min, s);
}
}