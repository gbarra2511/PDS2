#include <stdio.h>
#include <math.h>

int main(){
    float pi = 3.1415;
    float raio;{
        printf("Digite o raio da circunferencia:\n");
    scanf("%f", &raio);
    }
    float area = pi*pow(raio,2);
    float perimetro = 2*pi*raio;
    float volume = (4/3)*pi*pow(raio,3);
    printf("area = %.2f\n, volume = %.2f\n, perimetro = %.2f\n", area, volume, perimetro);
}