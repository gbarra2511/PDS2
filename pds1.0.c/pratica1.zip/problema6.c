#include <stdio.h>
#include <math.h>

int main(){
    float vp, vf, i;
    int n;
    printf("Digite o valor inicial:");
    scanf("%f", &vp);
    printf("digite a taxa de juros i anual:");
    scanf("%f", &i);
    printf("Digite o numero de anos:");
    scanf("%d", &n);
    vf = vp*pow((1+(i*0.01)),n);
    printf("vf e:%.2f",vf);
}