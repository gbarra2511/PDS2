#include <stdio.h>
#include <math.h>

int main(void){
    int n;
    printf("Digite o numero de quatro algarismos:\n");
    scanf("%d", &n);
    //n/1000 e o primeiro algarismo, n/100%10 e o segundo, n/10%10 e o terceiro e n%10 e o quarto.
    printf("o numero invertido e: %d %d %d %d\n", n%10, (n/10)%10, (n/100)%10, n/1000);
}