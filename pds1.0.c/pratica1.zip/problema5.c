#include <stdio.h>
#include <math.h>

int main(){
    int a,b,c;
    printf("Digite o valor de a:");
    scanf("%d", &a);

    printf("Digite o valor de b:");
    scanf("%d", &b);

    printf("Digite o valor de c:");
    scanf("%d", &c);
    
    int x = a*a;
    int y = b*b;
    int z = c*c;
    
    printf("a soma dos quadrados dos numeros e: %d\n", x+y+z);
    return 0;
}    