#include <stdio.h>
#include <math.h>

int main(void){
    int numero;
    int a, b, c, d, x;

    printf("Digite um inteiro de 4 algarismos:\n");
    scanf("%d",&numero);
    a = numero/1000;
    b = (numero%1000)/100;
    c = (numero%100)/10;
    d = numero%10;
    x = a+b+c+d;
    printf("Resultado:%d", x);
    return 0;
}