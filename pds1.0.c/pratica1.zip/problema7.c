#include <stdio.h>
#include <math.h>   

int main(void){
float pedro, joao, marcela;
int valor_premio;
float valor_premio_pedro, valor_premio_joao, valor_premio_marcela;
printf("digite o valor do premio:");
scanf("%d", &valor_premio);
printf("digite o valor investido por pedro, joao e marcela respectivamente:");
scanf("%f %f %f", &pedro, &joao, &marcela);
// pega a porcentagem de cada um em relacao ao total investido e multiplica pelo valor do premio
valor_premio_pedro = (pedro/(pedro+joao+marcela))*valor_premio;
valor_premio_joao = (joao/(pedro+joao+marcela))*valor_premio;
valor_premio_marcela = (marcela/(pedro+joao+marcela))*valor_premio;
printf("pedro ganhou: %.2f\n", valor_premio_pedro);
printf("joao ganhou:%.2f\n", valor_premio_joao);
printf("marcela ganhou:%.2f\n", valor_premio_marcela);
}