#include <stdio.h>
#include <math.h>

int main(void){
    float v0, a, t, vf, s;{
    printf("Digite a velocidade inicial:\n");
    scanf("%f", &v0);
    printf("digite a aceleracao:\n");
    scanf("%f",&a);
    printf("digite o tempo:\n");
    scanf("%f", &t);
    }
    vf = v0 + a*t;
    s = t*v0 + (a*pow(t,2))/2;

    printf("velocidade final= %.2f\n", vf);
    printf("distancia percorrida= %.2f\n", s);

}