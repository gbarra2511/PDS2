#include <stdio.h>
#include <math.h>

int main(void){
    float valor, valor_avista, parcela, comissao1, comissao2;;
    printf("Digite o valor da compra:");
    scanf("%f", &valor);
    valor_avista = valor*0.9;
    parcela = valor/6;
    comissao1 = valor_avista*0.05;
    comissao2 = valor*0.05;

    printf("Valor com desconto: %.2f\n", valor_avista);
    printf("Valor da parcela: %.2f\n", parcela);
    printf("Comissao do vendedor (a vista): %.2f\n", comissao1);
    printf("Comissao do vendedor (parcelado): %.2f\n", comissao2);
    return 0;
}